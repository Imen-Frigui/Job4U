/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pidevusers2;



import entities.User2;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import services.ServiceUser2;
import utils.MyConnection2;

/**
 *
 * @author user
 */
public class PidevUsers2 {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        

        
        
        MyConnection2 db=MyConnection2.getInstance();
        
        ServiceUser2 sp2 = new ServiceUser2();
        
        System.out.println(sp2.afficher());
        
         User2 p2 = new User2(3,"3ammar","maalam","jhvj@gmail.com","ammar712634","Candidat");
        
        sp2.ajouter(p2);
        
        
       try{
           sp2.ajouter2(p2);
       }catch(SQLException ex){
           System.out.println("Probleme insertion: "+ex.getMessage());
       }
        
        
     
    }
    
}
