
package services;

import entities.User2;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import interfaces.InterfaceUser2;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.MyConnection2;


////////////





/**
 *
 * @author user
 */
public class ServiceUser2 {
     Connection connection;
    Statement ste;

    public ServiceUser2() {
        connection = (Connection) MyConnection2.getInstance().getCnx();
    }
    
    
 
    public void ajouter(User2 u) {
        try {
            
            ste = connection.createStatement();
            String req ="INSERT INTO `pidevusers`.`users` (`Id`,`Nom`,`Prenom`,`Mail`,`Password`,`Role`) VALUES ('"+u.getId()+"'+'"+u.getNom()+"','"+u.getPrenom()+"','"+u.getMail()+"','"+u.getPassword()+"','"+u.getRole()+"');";
            ste.executeUpdate(req);
            
            //  String req ="INSERT INTO `esprit3a11`.`Personne` (`nom`,`prenom`,`age`) VALUES ('"+t.getNom()+"','"+t.getPrenom()+"',"+t.getAge()+");";
            
        } catch (SQLException ex) {
            System.out.println("Exception: "+ex.getMessage());
        }
        
        
        
        
       
    }
    
    
      
    public void ajouter2(User2 u) throws SQLException {
        PreparedStatement pre = connection.prepareStatement("INSERT INTO `pidevusers`.`users` (`Id`,`Nom`,`Prenom`,`Mail`,`Password`,`Role`) VALUES (?,?,?,?,?,?)");
        
           pre.setInt(1, u.getId());
        pre.setString(2, u.getNom());
        pre.setString(3, u.getPrenom());
        pre.setString(4, u.getMail());
        pre.setString(5, u.getPassword());
        pre.setString(6, u.getRole());
        
        pre.executeUpdate();
        
    }
    
    
    public ArrayList<User2> afficher() {
        ArrayList<User2> listpers = new ArrayList<>();
        try{
        ste= connection.createStatement();
        String req_select="SELECT * FROM `pidevusers`.`users`";
        ResultSet res = ste.executeQuery(req_select);
        while(res.next()){
            int id = res.getInt(1);
            String nom = res.getString(2);
            String prenom = res.getString(3);
            String mail = res.getString(4);
            String password = res.getString(5);
            String role = res.getString(6);
            
            User2 pr = new User2(id,nom,prenom,mail,password,role);
            listpers.add(pr);
        }
        }catch(SQLException ex){
            System.out.println("SQLException "+ex.getMessage());
        }
        
        return listpers;
    }
    
}
